﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class onHit : MonoBehaviour
{
    public bool isHit;
    public int hitSeverity, damage;
    public int iFrames;
    
    public Vector3 hitFrom, parentDirection, newDirection;
    private Vector3 v;
    private float parentSpeed;
    public int timer;
    // Start is called before the first frame update
    // Update is called once per frame
    private void Start()
    { 
    parentSpeed = GetComponent<CharacterStats>().speed;
        timer = -1;
        isHit = false;
    }
    void FixedUpdate()
    {
        parentDirection = GetComponent<Rigidbody2D>().velocity.normalized;
        if (isHit || timer >= 0)
        {
            if (timer <= iFrames - 10)
            {
                if (timer % 10 == 0 || (timer - 1) % 10 == 0)
                {
                    GetComponent<SpriteRenderer>().color = new Color(255, 255, 255, 0);
                }

                else
                {
                    GetComponent<SpriteRenderer>().color = new Color(255, 200, 200, 255);
                }
            }
            else
            {
                GetComponent<SpriteRenderer>().color = new Color(255, 255, 255, 255);

            }
            if (timer < 0)
            {
                GetComponent<CharacterStats>().hp -= damage;
                v = hitFrom.normalized;

                    if(hitFrom.x <= 0)
                    newDirection = -Vector2.Perpendicular(new Vector2(v.x, v.y));
                    else
                    newDirection = Vector2.Perpendicular(new Vector2(v.x, v.y));


            }
            if (timer <= 10)
            {
               
                GetComponent<Rigidbody2D>().velocity = newDirection * hitSeverity;

            }
            else if (timer <= 25)
            {
                GetComponent<Movement>().enabled = false;
            }
            else
            {
                GetComponent<Movement>().enabled = true;

                GetComponent<Movement>().speed = parentSpeed;
            }
            timer++;
            isHit = false;

            if(timer >= iFrames)
            {
                timer = -1;

            }
        }
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1, 0, 0, 0.75F);

        Gizmos.DrawLine(transform.position, transform.position+ (newDirection * hitSeverity));



    }
}
