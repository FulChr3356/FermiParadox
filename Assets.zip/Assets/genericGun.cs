﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class genericGun : MonoBehaviour
{
    private float fireTimer;
    public float chaseTime;
    public GameObject bulletPrefab;
    private GameObject bullet;
    public int allowedBullets, bulletDamage;
    public Vector3 target;
    public AnimationClip flightAnimation, deathAnimation;
    public Transform targetHoming;
    public bool isHostile;
    public float bulletLife, firingDelay, bulletSpeed;
    public int aliveBullets;
    //public Animator desiredAnimation;
    public enum Pattern
    {
        straight, wave, gravity, homing
    };
    private void Start()
    {
        bulletLife *= 60;
        firingDelay *= 60;
    }
    public Pattern pattern;
    public Sprite bulletSprite;
    public bool firing;
    public float lifeTimer;
    // Start is called before the first frame update
    private void Update()
    {
        lifeTimer %= bulletLife +5;
        if (aliveBullets > 0 && (lifeTimer >= bulletLife || !firing))
        {
            lifeTimer = 0;
            aliveBullets--;
        }
    }
    // Update is called once per frame
    void FixedUpdate()
    {
            lifeTimer++;
        if(firingDelay >= fireTimer)
        {
            fireTimer++;
        }
        else if (firing && aliveBullets <= allowedBullets)
        {
            fireTimer = 0;
            aliveBullets++;
            bullet = Instantiate(bulletPrefab);
            bullet.GetComponent<SpriteRenderer>().enabled = true;
            bullet.GetComponent<CircleCollider2D>().enabled = true;
            bullet.GetComponent<bullet>().enabled = true;

            if (flightAnimation != null || deathAnimation != null)
                bullet.GetComponent<Animator>().enabled = true;
            var bulletCode = bullet.GetComponent<bullet>();
            bullet.transform.position = transform.position;
            bulletCode.life = bulletLife;
            bulletCode.damage = bulletDamage;
            bulletCode.hostile = isHostile;
            bulletCode.sprite = bulletSprite;
            bulletCode.speed = bulletSpeed;
            bulletCode.target = target;
            bulletCode.flight = flightAnimation;
            if(targetHoming != null)
                bulletCode.targetHoming = targetHoming;
            bulletCode.hit = deathAnimation;
            bulletCode.friendlyGun = transform.parent.gameObject;
           // bullet.GetComponent<Animator>().runtimeAnimatorController = desiredAnimation.runtimeAnimatorController;



            switch (pattern)
            {
                case Pattern.homing:
                    bulletCode.pattern = global::bullet.Pattern.homing;

                    bulletCode.chaseTime = chaseTime;


                    break;
                case Pattern.wave:
                    bullet.GetComponent<bullet>().pattern = global::bullet.Pattern.wave;
                    break;
                case Pattern.gravity:
                    bullet.GetComponent<bullet>().pattern = global::bullet.Pattern.gravity;
                    break;
                default:
                    bullet.GetComponent<bullet>().pattern = global::bullet.Pattern.straight;
                    break;
            }
        }
    }
}
