﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStats : MonoBehaviour
{
    public int maxHP,hp;
    public float speed;
    public float chargeAmt;
    public int deathTimer;
    private bool hasDied;
    public void Start()
    {
        hasDied = false;
    }

    public void FixedUpdate()
    {
        if(hp <= 0 && !hasDied)
        {
            if(GetComponent<Movement>() != null)
             GetComponent<Movement>().enabled = false;
            GetComponent<Animator>().SetBool("dead", true);
            hasDied = true;
        }
        else if(deathTimer <= 0)
        {
            Destroy(transform.gameObject);
        }
        else if (hasDied)
        {
            deathTimer--;
        }
    }
}
