﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopDownEnemy : MonoBehaviour
{
    public enum States {  Default, Hostile };

    public List<Transform> waypoints;
    public States state;
    public Animator anim;
    public int currWaypoint = 0;
    private int timer;
    public Transform player;

    private float speed;
    private CharacterStats enStats;
    private Rigidbody2D rigid;

    public float threshold = .05f;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        rigid = GetComponent<Rigidbody2D>();
        enStats = GetComponent<CharacterStats>();
        timer = 0;
        speed = enStats.speed;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Vector3 moveTo;
                moveTo = waypoints[currWaypoint].position;

        Vector2 dir = (moveTo - transform.position).normalized;

        rigid.velocity = dir * speed;

        if((waypoints[currWaypoint].position - transform.position).magnitude < threshold)
        {
            if (timer <= 30)
            {
                rigid.velocity = dir * 0.5f * speed;
                timer++;
            }
            else
            {
                speed = enStats.speed;
                timer = 0;
                currWaypoint++;
                if (currWaypoint >= waypoints.Count)
                {
                    currWaypoint = 0;
                }
            }
        }

    }

     void OnTriggerEnter2D(Collider2D coll)
    {
        //print("test");
        if(coll.gameObject.name.Equals("bluecircle"))
        {
            state = States.Hostile;
            anim.SetBool("hostile", true);
            GetComponentInChildren<genericGun>().target = coll.transform.position;
            GetComponentInChildren<genericGun>().targetHoming = coll.transform;
            GetComponentInChildren<genericGun>().firing = true;
        }

    }
    private void OnTriggerStay2D(Collider2D coll)
    {
        if (coll.gameObject.name.Equals("bluecircle"))
            {
                GetComponentInChildren<genericGun>().target = coll.transform.position;
                GetComponentInChildren<genericGun>().targetHoming = coll.transform;
            }
    }
    void OnTriggerExit2D(Collider2D coll)
    {
        if (coll.gameObject.name.Equals("bluecircle"))
        {
            state = States.Default;
            anim.SetBool("hostile", false);
            GetComponentInChildren<genericGun>().firing = false;
        }
    }
}
