﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopDownPlayer : MonoBehaviour
{
    private float speed;
    private Rigidbody2D rigid;
    private CharacterStats plStats;
    // Start is called before the first frame update
    void Start()
    {

        rigid = GetComponent<Rigidbody2D>();
        plStats = GetComponent<CharacterStats>();
        speed = plStats.speed;

    }
    // Update is called once per frame
    void FixedUpdate()
    {
        rigid.velocity = new Vector2(Mathf.Lerp(0, Input.GetAxis("Horizontal") * speed, 0.8f), Mathf.Lerp(0, Input.GetAxis("Vertical") * speed, 0.8f));

        //  print(speed);
        // Debug.Log("Hello");

    }
}
