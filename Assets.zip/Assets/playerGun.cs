﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerGun : MonoBehaviour
{
    private Vector2 mouse, mouseWorld;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        mouse = Input.mousePosition;
        mouseWorld = Camera.main.ScreenToWorldPoint(mouse);
       // print(mouseWorld);
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            transform.GetChild(3).GetComponent<genericGun>().target = mouseWorld;
            transform.GetChild(3).GetComponent<genericGun>().firing = true;
        }
        else
        {
            transform.GetChild(3).GetComponent<genericGun>().firing = false;
        }


    }
}
