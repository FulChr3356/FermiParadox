﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    public Sprite sprite;
    private bool hasHit = false;
    public bool debug;
    public GameObject friendlyGun;
    private Rigidbody2D rigid;
    public float life, speed;
    public float chaseTime;
    public int damage;
    public Vector3 target;
    public Transform targetHoming;
    public bool hostile;
    public AnimationClip flight, hit;
    private bool homing;
    private Animator anim;
    private AnimatorOverrideController animOver;
    public enum Pattern
    {
        straight, wave, gravity, homing
    };
    private Vector3 mVector = Vector3.zero;
    public Pattern pattern;

    // Start is called before the first frame update
    void Start()
    { 
    anim = GetComponent<Animator>();
        GetComponent<SpriteRenderer>().sprite = sprite;
        rigid = GetComponent<Rigidbody2D>();

         switch (pattern)
        {
            case Pattern.homing:
                homing = true;
                break;
            default:
                homing = false;
                mVector = (target - transform.position).normalized * speed;
                break;

        }

    }
    void Update()
    {
        if (hasHit)
        {
            if (Time.deltaTime >= hit.length)
                Destroy(transform.gameObject);
        }
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        
        life--;
        if ( life <= -100)
        {
            StopAllCoroutines();
        }
        else if (life <= 0)
            Destroy(this.gameObject);
        if(!homing)
        {
            print(mVector);
            transform.position += mVector * Time.fixedDeltaTime;

        }
        else
        {
            if (chaseTime >= 0)
            {
                chaseTime -= Time.fixedDeltaTime;
                GetComponent<SpriteRenderer>().color = new Color(255, 125, 125, 255);
                mVector = (targetHoming.position - transform.position).normalized * speed;


            }
            else
            {
                homing = false;
                print("No!");
                GetComponent<SpriteRenderer>().color = new Color(255, 255, 255, 255);

            }
            transform.position += mVector * Time.fixedDeltaTime;
        }
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1, 1, 0, 0.75F);

        Gizmos.DrawLine(transform.position, target);

    }
    private void OnTriggerEnter2D(Collider2D coll)
    {
        if (!coll.isTrigger)
        {
           
            print("Whee!");
            if (targetHoming != null && coll.name.Equals(targetHoming.name) && !hasHit)
            {


                if (targetHoming.GetComponent<onHit>())
                {
                    targetHoming.GetComponent<onHit>().isHit = true;
                    targetHoming.GetComponent<onHit>().hitFrom = mVector;
                    targetHoming.GetComponent<onHit>().damage = damage;

                }
                if (anim.enabled)
                {
                    anim.SetBool("hit", true);
                    mVector = new Vector3(0, 0, 0);

                }
            }
            else if (!hasHit && coll.gameObject != friendlyGun && !coll.transform.IsChildOf(friendlyGun.transform))
            {
                hasHit = true;
                if (anim.enabled)
                {
                    anim.SetBool("hit", true);
                    mVector = new Vector3(0, 0, 0);

                }
                if (coll.transform.parent != null)
                {
                        if (coll.transform.parent.GetComponent<onHit>())
                        {
                            coll.transform.parent.GetComponent<onHit>().isHit = true;
                            coll.transform.parent.GetComponent<onHit>().hitFrom = mVector;
                            coll.transform.parent.GetComponent<onHit>().damage = damage;

                        }
                        else if (coll.transform.parent.GetComponent<CharacterStats>())
                        {
                        coll.transform.parent.GetComponent<CharacterStats>().hp--;
                        }


                }
            }

        }


 

    }
}
